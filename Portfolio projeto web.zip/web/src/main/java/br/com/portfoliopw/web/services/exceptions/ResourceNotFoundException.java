package br.com.portfoliopw.web.services.exceptions;

public class ResourceNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	 public ResourceNotFoundException(Object id) {
		 super ("Não localizamos um usuàrio com a id " + id  );
	 }

}
