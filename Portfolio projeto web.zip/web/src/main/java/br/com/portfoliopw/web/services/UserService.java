package br.com.portfoliopw.web.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.portfoliopw.web.entities.User;
import br.com.portfoliopw.web.repositories.UserRepository;
import br.com.portfoliopw.web.services.exceptions.ResourceNotFoundException;

@Service
public class UserService {
	
	@Autowired
	private UserRepository repository;
	
	public List<User> findAll(){
		return repository.findAll();
	}
	
	public User findById(Long id) {
		
		Optional<User> usuario= repository.findById(id);
		return usuario.orElseThrow(() -> new ResourceNotFoundException(id));
	}
	
	public User insert(User usuario) {
		return repository.save(usuario);
	}
	
	public void delete(Long id) {
		
		 try {
		  repository.deleteById(id);
	} catch (ResourceNotFoundException e) {
		//TODO:handle exception
	}
	}
		  
	  
	 public User update (Long id, User usuario) {
		 try {
		 User cadastro =repository.getReferenceById(id);
		 updatedados(cadastro, usuario);
		 return repository.save(cadastro); 
		 } catch(RuntimeException e) {
			 throw new ResourceNotFoundException(id);
		 }
		 
	 }

	private void updatedados(User cadastro, User usuario) {
		cadastro.setNome(usuario.getNome());
		cadastro.setEmail(usuario.getEmail());
		cadastro.setTelefone(usuario.getTelefone());
		
		
	}
}


